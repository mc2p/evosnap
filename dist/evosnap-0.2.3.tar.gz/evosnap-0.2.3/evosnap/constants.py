LIVE=False
PROXY=False
PROXY_HOST='127.0.0.1'
PROXY_PORT=8888
TRUST_ALL=False

ALL_FIELDS='__ALL__'

SESSION_TOKEN_TIME = 1740

CWS_SIS_BASEURL = 'https://api.cip.goevo.com/2.1.27/REST/SIS.svc'
CWS_TPS_BASEURL = 'https://api.cip.goevo.com/2.1.27/REST/TPS.svc'
CWS_TMS_BASEURL = 'https://api.cip.goevo.com/2.1.27/REST/DataServices/TMS.svc'
CWS_UAT_SIS_BASEURL = 'https://api.cipcert.goevo.com/2.1.27/REST/SIS.svc'
CWS_UAT_TPS_BASEURL = 'https://api.cipcert.goevo.com/2.1.27/REST/TPS.svc'
CWS_UAT_TMS_BASEURL = 'https://api.cipcert.goevo.com/2.1.27/REST/DataServices/TMS.svc'
