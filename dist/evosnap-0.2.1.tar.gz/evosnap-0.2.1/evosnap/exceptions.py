class SignOnException(Exception):
    pass

class AppProfileException(Exception):
    pass

class TransactionRequestException(Exception):
    pass
